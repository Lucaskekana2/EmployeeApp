package com.gui.controllers;

import java.io.Serializable;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import com.ejb.services.EmployeeService;
import com.jpa.entities.Employee;

@Named
@SessionScoped
public class EmployeeController implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Employee employee = new Employee();

	@EJB
    private EmployeeService service;

    public Employee getEmployee() {
    	return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public void saveEmployee(Employee emp) {
		service.addEmployee(emp);
	}

}