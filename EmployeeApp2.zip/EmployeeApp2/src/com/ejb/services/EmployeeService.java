package com.ejb.services;

import com.jpa.entities.Employee;

public interface EmployeeService {

	public void addEmployee(Employee emp);
	
}